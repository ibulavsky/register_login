interface ISomeAction {
    type: string;
}

export type INekoActions = ISomeAction;
