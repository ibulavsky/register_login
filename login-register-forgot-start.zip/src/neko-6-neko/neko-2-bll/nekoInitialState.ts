export interface INekoState {

}

export const nekoInitialState: INekoState = {

};
