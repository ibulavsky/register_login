import React from 'react';
import Neko from "./Neko";

const NekoContainer: React.FC = () => {
    // logic

    return (
        <Neko/>
    );
};

export default NekoContainer;
