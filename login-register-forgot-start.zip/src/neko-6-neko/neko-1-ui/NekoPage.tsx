import React from 'react';
import NekoContainer from "./NekoContainer";

const NekoPage: React.FC = () => {
    return (
        <NekoContainer/>
    );
};

export default NekoPage;
