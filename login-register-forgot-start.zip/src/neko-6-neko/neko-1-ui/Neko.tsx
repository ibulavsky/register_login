import React from 'react';

interface NekoProps {

}

const Neko: React.FC<NekoProps> = ({}) => {

    return (
        <div>
            neko
        </div>
    );
};

export default Neko;
