import React from 'react';
import RegisterContainer from "./RegisterContainer";

const RegisterPage: React.FC = () => {
    return (
        <RegisterContainer/>
    );
};

export default RegisterPage;
