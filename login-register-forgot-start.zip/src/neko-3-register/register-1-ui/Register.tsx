import React from 'react';

interface RegisterProps {

}

const Register: React.FC<RegisterProps> = ({}) => {

    return (
        <div>
            register
        </div>
    );
};

export default Register;
