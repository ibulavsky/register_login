import React from 'react';
import Register from './Register';

const RegisterContainer: React.FC = () => {
    // logic

    return (
        <Register/>
    );
};

export default RegisterContainer;
