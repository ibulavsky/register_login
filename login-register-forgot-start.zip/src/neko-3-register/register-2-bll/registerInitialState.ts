export interface IRegisterState {

}

export const registerInitialState: IRegisterState = {

};
