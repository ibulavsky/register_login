interface ISomeAction {
    type: string
}

export type IRegisterActions = ISomeAction;

