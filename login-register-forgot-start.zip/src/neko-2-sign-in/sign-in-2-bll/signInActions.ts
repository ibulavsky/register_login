interface ISameAction {
    type: string;
}

export type ISignInActions = ISameAction;

