export interface ISignInState {

}

export const signInInitialState: ISignInState = {

};
