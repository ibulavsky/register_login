import React from 'react';
import SignInContainer from "./SignInContainer";

const SignInPage: React.FC = () => {
    return (
        <SignInContainer/>
    );
};

export default SignInPage;
