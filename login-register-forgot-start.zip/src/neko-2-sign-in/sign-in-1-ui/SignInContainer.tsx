import React from 'react';
import SignIn from "./SignIn";

const SignInContainer: React.FC = () => {
    // logic

    return (
        <SignIn/>
    );
};

export default SignInContainer;
