import React from 'react';
import Forgot from './Forgot';

const ForgotContainer: React.FC = () => {
    // logic

    return (
        <Forgot/>
    );
};

export default ForgotContainer;
