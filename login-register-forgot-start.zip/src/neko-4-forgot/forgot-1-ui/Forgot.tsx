import React from 'react';

interface ForgotProps {

}

const Forgot: React.FC<ForgotProps> = ({}) => {

    return (
        <div>
            forgot
        </div>
    );
};

export default Forgot;
