import React from 'react';
import ForgotContainer from './ForgotContainer';

const ForgotPage: React.FC = () => {
    return (
        <ForgotContainer/>
    );
};

export default ForgotPage;
