interface ISomeAction {
    type: string;
}

export type IForgotActions = ISomeAction;
