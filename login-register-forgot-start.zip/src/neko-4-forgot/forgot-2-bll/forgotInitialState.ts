export interface IForgotState {

}

export const forgotInitialState: IForgotState = {

};
